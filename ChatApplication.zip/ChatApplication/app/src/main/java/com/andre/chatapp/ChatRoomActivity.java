package com.andre.chatapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.andre.chatapp.MessageAdapter;
import com.andre.chatapp.R;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class ChatRoomActivity extends AppCompatActivity {
    MessageAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_room);

        Intent intent = getIntent();
        int convId = intent.getIntExtra(MainActivity.CONVERSATION_ID, 0);
        setTitle("Conversation " + convId);

        RecyclerView rv = (RecyclerView) findViewById(R.id.messages);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MessageAdapter(this);
        rv.setAdapter(adapter);

        try {
            new LoadMessages(new LoadMessages.OnPostExecute() {
                @Override
                public void onPostExecute(List<Message> messages) {
                    adapter.setMessages(messages);
                }
            }).execute(new URL("http://00000000000000000000000000000:8080//ChatApplication/api/messages?name=" + convId));
        }   catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
    }

    public void sendMessage(View view)
    {
        EditText enterMsg = (EditText) findViewById(R.id.enterMsg);
        String message = enterMsg.getText().toString();

        postMessage(message);
    }

    public void postMessage(String msg)
    {
        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText(msg);
    }


}
