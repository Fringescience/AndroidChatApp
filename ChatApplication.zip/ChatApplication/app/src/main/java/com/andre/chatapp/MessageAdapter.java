package com.andre.chatapp;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.andre.chatapp.R;

import java.util.List;

/**
 * Created by g6-2011 on 19.10.2017.
 */

class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {

    List<Message> messages;
    Context context;

    View.OnClickListener listener;

    public MessageAdapter(Context context)
    {
        this.context = context;
    }

    public interface OnClicListener
    {
        void onClick(int position);
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
        notifyDataSetChanged();
    }

    @Override
    public MessageAdapter.MessageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.message,parent,false);
        return new MessageViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MessageAdapter.MessageViewHolder holder, int position) {
    Message message = messages.get(position);
        picasso.with(context)
                .load(Uri.parse(message.getMessage() + "?width=400")
                .into(holder.message));
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }







    public class MessageViewHolder extends RecyclerView.ViewHolder
    {
        public ImageView message;

        public MessageViewHolder(View view)
        {
            super(view);
            this.message = view.findViewById(R.id.messageView);

            view.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    if(listener != null)
                    {
                        listener.onClick(getAdapterPosition());
                    }
                }
            });
        }
    }
}
